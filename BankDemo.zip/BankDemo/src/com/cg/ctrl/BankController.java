package com.cg.ctrl;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.Account;
import com.cg.exceptions.AccountBlockedException;
import com.cg.exceptions.InsufficientAmountException;
import com.cg.exceptions.InvalidPinNumberException;
import com.cg.service.BankService;

@Controller
public class BankController {
	@Autowired
	BankService bankService=null;

	public BankService getBankService() {
		return bankService;
	}

	public void setBankService(BankService bankService) {
		this.bankService = bankService;
	}
	@RequestMapping(value="/OpenAccountPage")
	public String dispRegPage(Model model) {

		Account ac=new Account();
		model.addAttribute("reg",ac);

		return "openAccount";

	}
	@RequestMapping(value="/openAccount",method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="reg")
	@Valid
	Account rd,BindingResult result,Model model) {

		Account account=bankService.openAccount(rd);
		model.addAttribute("account", account);
		return "success";

	}

	@RequestMapping(value="/depositeAmount")
	public String dipositePage(Model model) {

		Account ac=new Account();
		model.addAttribute("reg",ac);

		return "depositeAmount";

	}

	@RequestMapping(value="/depositedAmount",method=RequestMethod.POST)
	public String depositedAmount(@ModelAttribute(value="reg")	Account rd,BindingResult result,Model model) {
		float balance=bankService.depositAmount(rd.getAccountNo(), rd.getAccountBalance());
		model.addAttribute("balance", balance);
		return "depositedAmount";

	}


	@RequestMapping(value="/withdrawAmount")
	public String withdrawPage(Model model) {

		Account ac=new Account();
		model.addAttribute("reg",ac);

		return "withdrawAmount";

	}
	@RequestMapping(value="/withdrawAmountSuccess",method=RequestMethod.POST)
	public String withdrawAmount(@ModelAttribute(value="reg")	Account rd,BindingResult result,Model model) {
		float balance=bankService.withdrawAmount(rd.getAccountNo(), rd.getAccountBalance(), rd.getPinNumber());
		model.addAttribute("balance", balance);
		return "withdrawAmountSuccess";

	}
	@RequestMapping(value="/fundTransfer")
	public String fundTransferPage(Model model) {

		Account ac=new Account();
		model.addAttribute("reg",ac);

		return "fundTransfer";

	}
	@RequestMapping(value="/fundTransferSuccess",method=RequestMethod.POST)
	public String fundTransfer(@ModelAttribute(value="reg")	Account rd,BindingResult result,Model model) {

		try {
			boolean balance = bankService.fundTransfer(rd.getAccountNo(), rd.getAccountNo(), rd.getAccountBalance(), rd.getPinNumber());
			model.addAttribute("balance", rd.getAccountBalance());
		} catch (InvalidPinNumberException | InsufficientAmountException | AccountBlockedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "fundTransferSuccess";

	}

	@RequestMapping(value="/getAccount")
	public String getAccountPage(Model model) {

		Account ac=new Account();
		model.addAttribute("reg",ac);

		return "getAccount";

	}
	@RequestMapping(value="/getAccountDetail",method=RequestMethod.POST)
	public String getAccountDetail(@ModelAttribute(value="reg")	Account rd,BindingResult result,Model model) {
		Account account=bankService.getAccountDetails(rd.getAccountNo());
		model.addAttribute("account", account);
		return "getAccountDetails";

	}

}
