package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Cart;
import com.cg.capstore.bean.OrderItems;
import com.cg.capstore.dao.InvoiceDao;
import com.cg.capstore.dao.InvoiceDaoImpl;

@Service
public class InvoiceServiceImpl implements InvoiceService{
	
	@Autowired
	InvoiceDao invoicedao;
	
	public InvoiceDao getInvoicedao() {
		return invoicedao;
	}

	public void setInvoicedao(InvoiceDao invoicedao) {
		this.invoicedao = invoicedao;
	}

	@Override
	public List<Cart> findCart() {
	return invoicedao.findCart();
	}

	@Override
	public List<OrderItems> findOrderItems() {
		return invoicedao.findOrderItems();
		
	}
}