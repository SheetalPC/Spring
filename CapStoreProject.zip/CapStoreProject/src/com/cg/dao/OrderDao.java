package com.cg.dao;

import com.cg.dto.Order;

public interface OrderDao {
	public Order findDetails(int refund_request);
	public Order getRefundRequest(boolean refund_request);
	public Order findId(String order_id);
}
