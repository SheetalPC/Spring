package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Order;

@Repository
@Transactional
public class OrderDaoImpl implements OrderDao{

	@PersistenceContext
	EntityManager entityManager = null;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Order findDetails(int refund_request) {
		return entityManager.find(Order.class, refund_request);
	}

	@Override
	public Order getRefundRequest(boolean refund_request) {
		return null;
	}

	@Override
	public Order findId(String order_id) {
		Query query = entityManager.createQuery("from Order o where o.order_id=:order_id");
		query.setParameter("order_id", order_id);
		return (Order) query.getSingleResult();
	}
	
	
}
