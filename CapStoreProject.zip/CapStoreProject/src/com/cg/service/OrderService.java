package com.cg.service;

import com.cg.dto.Order;

public interface OrderService {
	public Order findDetails(int refund_request);
	public Order getRefundRequest(boolean refund_request);
	public Order findId(String order_id);
}
