package com.cg.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.OrderDao;
import com.cg.dto.Order;

@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	OrderDao orderDao = null;

	public OrderDao getOrderDao() {
		return orderDao;
	}

	public void setOrderDao(OrderDao orderDao) {
		this.orderDao = orderDao;
	}

	public OrderServiceImpl() {
		super();
	}

	@Override
	public Order getRefundRequest(boolean refund_request) {
		return orderDao.getRefundRequest(refund_request);
	}

	@Override
	public Order findDetails(int refund_request) {
		return orderDao.findDetails(refund_request);
	}

	@Override
	public Order findId(String order_id) {
		return orderDao.findId(order_id);
	}
}
