package com.cg.ctrl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.dto.Order;
import com.cg.service.OrderService;

@Controller
public class CapStoreController {
	
	@Autowired
	OrderService orderService = null;
	
	public OrderService getOrderService() {
		return orderService;
	}

	public void setOrderService(OrderService orderService) {
		this.orderService = orderService;
	}

	public CapStoreController() {
		super();
	}

	@RequestMapping(value = "/ProductVerification" , method = RequestMethod.GET)
	public String getDetails(Model model) {
		model.addAttribute("details", new Order());
		return "ProductVerificationPage";
	}
	
	@RequestMapping(value = "/ValidateUser", method = RequestMethod.POST)
	public String validateUser(@ModelAttribute(value = "details") Order order, BindingResult bindingResult, Model model) {
		//Order or=OrderService.findDetails(order.isRefund_request());
		//System.out.println(order.toString());
		Order ord = orderService.findId(order.getOrder_id());
		//System.out.println("order detail is : "+ord);
		if (ord.isRefund_request()==1)
			return "RefundSuccessPage";
		else if(ord.isRefund_request()==0)
			return "Failure";
		return "Fail";
	}
	
	/*@RequestMapping(value="/admin",method=RequestMethod.POST)
    public String adminVerify(@ModelAttribute(value="details")Order order,BindingResult result,Model model) {
      Order or=OrderService.findDetails(order.isRefund_request());
      if(or==true) {
            return "RefundSuccessPage";
        }
        else {
        return "Fail";
        }
	}
  */
}
