package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.HotelBooking;

public interface IBookingDAO {
	public ArrayList<HotelBooking> getAllBookingDetails();
	public HotelBooking insertDetails(HotelBooking hotelBooking);
}
