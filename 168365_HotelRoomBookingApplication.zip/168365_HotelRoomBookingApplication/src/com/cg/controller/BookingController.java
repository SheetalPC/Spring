package com.cg.controller;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.dto.HotelBooking;
import com.cg.service.IBookingService;

@Controller
public class BookingController {
	@Autowired
	IBookingService bookingService = null;
	
	public IBookingService getBookingService() {
		return bookingService;
	}
	public void setBookingService(IBookingService bookingService) {
		this.bookingService = bookingService;
	}

	@RequestMapping(value="/HotelDetails",method=RequestMethod.GET)
	public String listAllHotels(@ModelAttribute(value="reg") HotelBooking hd,
	        BindingResult result,Model model) {
	    
	    ArrayList<HotelBooking>hotelList=bookingService.getAllBookingDetails();
	    model.addAttribute("hotelListObj", hotelList);
	            return "HotelDetails";
	}
	
	@RequestMapping(value="/HotelBookingSuccess",method=RequestMethod.GET)
	public String DisplayTrainee(@ModelAttribute(value="${user.name}") HotelBooking hd,
	        BindingResult result,Model model) {
	    
	    model.addAttribute("trainee", hd);
	    return "HotelBookingSuccess";
	}
	
	@RequestMapping("/HiltonHotel")
	public String displayHiltonHotel(Model model) {
		HotelBooking hotelBooking = new HotelBooking();
		model.addAttribute("msg", "Hilton Hotel"); 
		return "HotelBookingSuccessPage";
	}
	
	@RequestMapping("/VivantaByTAJ")
	public String displayVivanta(Model model) {
		HotelBooking hotelBooking = new HotelBooking();
		model.addAttribute("msg", "Vivanta By TAJ"); 
		return "HotelBookingSuccessPage";
	}
		
	@RequestMapping("/NewGingerResort")
		public String displayGinger(Model model) {
			HotelBooking hotelBooking = new HotelBooking();
			model.addAttribute("msg", "New Ginger Resort");
			return "HotelBookingSuccessPage";
	}
			
	@RequestMapping("/WoodlandsHotel")
			public String displayWoodlands(Model model) {
				HotelBooking hotelBooking = new HotelBooking();
				model.addAttribute("msg", "Woodlands Hotel");
				return "HotelBookingSuccessPage";
		}
}