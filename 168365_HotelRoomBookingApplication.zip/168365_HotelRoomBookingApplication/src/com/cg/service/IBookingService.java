package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.HotelBooking;

public interface IBookingService {
	public ArrayList<HotelBooking> getAllBookingDetails();
	public HotelBooking insertDetails(HotelBooking hotelBooking);
}
