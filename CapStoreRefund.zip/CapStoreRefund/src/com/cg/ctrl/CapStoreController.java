package com.cg.ctrl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.dto.Refund;
import com.cg.service.OrderService;

@Controller
public class CapStoreController {
	
	@Autowired
	OrderService OrderService = null;
	
	
	public OrderService getCapStoreService() {
		return OrderService;
	}

	public void setCapStoreService(OrderService capStoreService) {
		this.OrderService = capStoreService;
	}

	
	@RequestMapping(value = "/ProductVerification" , method = RequestMethod.GET)
	public String getDetails(Model model) {
		model.addAttribute("details", new Refund());
		return "FirstPage";
	}
	
	@RequestMapping(value = "/getId" , method = RequestMethod.GET)
	public String verify(Model model) {
		model.addAttribute("details1", new Refund());
		return "FirstPage";
	}
  
}
