package com.cg.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.OrderDao;


@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	OrderDao OrderDao = null;

	public OrderDao getCapStoreDao() {
		return OrderDao;
	}

	public void setCapStoreDao(OrderDao capStoreDao) {
		this.OrderDao = capStoreDao;
	}



}
