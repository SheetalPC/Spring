package com.cg.service;



public interface OrderService {
	
}
