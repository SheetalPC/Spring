package com.cg.dto;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Details_Order")
public class Order {
	private int orderId;
	private int quantity;
	private int amount;
	
}
