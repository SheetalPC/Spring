package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Account;
@Repository
@Transactional
public class AccountDaoImpl implements AccountDao{
	@PersistenceContext
	 EntityManager entityManager=null;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Account save(Account account) {
		entityManager.persist(account);
		Account ac=entityManager.find(Account.class, account.getAccountNo());
		return ac;
	}

	@Override
	public boolean update(Account account) {
		entityManager.merge(account);
		return true;
	}

	@Override
	public Account findOne(long accountNo) {
		// TODO Auto-generated method stub
		return entityManager.find(Account.class, accountNo);
	}

	@Override
	public List<Account> findAll() {
		Query query=entityManager.createQuery("from Account a");
		return query.getResultList();
	}

}
