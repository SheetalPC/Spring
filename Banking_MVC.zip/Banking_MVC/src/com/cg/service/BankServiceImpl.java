package com.cg.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.dao.AccountDao;
import com.cg.dao.TransactionDAO;
import com.cg.exceptions.AccountBlockedException;
import com.cg.exceptions.InsufficientAmountException;
import com.cg.exceptions.InvalidPinNumberException;
@Service
public class BankServiceImpl implements BankService{

	@Autowired
	AccountDao accountdao=null;
	@Autowired
	TransactionDAO transactiondao=null;
	public TransactionDAO getTransactiondao() {
		return transactiondao;
	}
	public void setTransactiondao(TransactionDAO transactiondao) {
		this.transactiondao = transactiondao;
	}

	public AccountDao getAccountdao() {
		return accountdao;
	}

	public void setAccountdao(AccountDao accountdao) {
		this.accountdao = accountdao;
	}

	@Override
	public Account openAccount(Account account) {
		account.setPinNumber(Integer.parseInt(String.format("%04d", new Random().nextInt(1000))));
		account.setStatus("Active");
		return accountdao.save(account);
	}

	@Override
	public float depositAmount(long accountNo, float amount) {
		Account account=accountdao.findOne(accountNo);
		account.setAccountBalance(account.getAccountBalance()+ amount);
		Transaction transaction= new Transaction(amount, "Deposit", account);
		transactiondao.save(transaction);
		accountdao.update(account);
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) {
		Account account= accountdao.findOne(accountNo);
		if(accountdao.findOne(accountNo)!= null)
		if(accountdao.findOne(accountNo).getStatus().equals("Active")) 
		if(pinNumber== account.getPinNumber())
		if(account.getAccountBalance()>amount)
		account.setAccountBalance(account.getAccountBalance()-amount);
		accountdao.update(account);
		Transaction transaction= new Transaction(amount, "Withdraw", account);
		transactiondao.save(transaction);
		return account.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber) throws InvalidPinNumberException, InsufficientAmountException, AccountBlockedException {
		Account accountFrom= accountdao.findOne(accountNoFrom);
		Account accountTo= accountdao.findOne(accountNoTo);
	
		if(pinNumber== accountFrom.getPinNumber()) throw new InvalidPinNumberException();
		if(!accountFrom.getStatus().equals("Active")|| !accountTo.getStatus().equals("Active")) throw new AccountBlockedException();
		if(accountFrom.getAccountBalance()< transferAmount) throw new InsufficientAmountException();
		accountFrom.setAccountBalance(accountFrom.getAccountBalance()- transferAmount);
		accountTo.setAccountBalance(accountTo.getAccountBalance()+ transferAmount);
		accountdao.update(accountFrom);
		accountdao.update(accountTo);
		return true;
	}
	@Override
	public Account getAccountDetails(long accountNo) {
		// TODO Auto-generated method stub
		return accountdao.findOne(accountNo);
	}
	@Override
	public List<Account> getAllAccountDetails() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String accountStatus(long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

}
