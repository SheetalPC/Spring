package com.cg.service;

import java.util.List;

import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.exceptions.AccountBlockedException;
import com.cg.exceptions.InsufficientAmountException;
import com.cg.exceptions.InvalidPinNumberException;

public interface BankService {
	Account openAccount(Account account);
	float depositAmount(long accountNo,float amount);
	float withdrawAmount(long accountNo,float amount,int pinNumber);

	boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber) throws InvalidPinNumberException, InsufficientAmountException, AccountBlockedException;

	Account getAccountDetails(long accountNo);

	List<Account> getAllAccountDetails();

	List<Transaction> getAccountAllTransaction(long accountNo);

	public String accountStatus(long accountNo);
}
