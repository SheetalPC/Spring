package com.cg.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.dto.QueryMaster;
import com.cg.service.QueryService;

@Controller
public class QueryController {
	@Autowired
	QueryService queryService;

	public QueryService getQueryService() {
		return queryService;
	}

	public void setQueryService(QueryService queryService) {
		this.queryService = queryService;
	}
	
	@RequestMapping(value = "/acceptId" , method = RequestMethod.GET)
	public String acceptId(Model model) {
		model.addAttribute("id",new QueryMaster());
		return "FirstPage";
	}
	
	@RequestMapping(value = "/QueryPage" , method = RequestMethod.POST)
	public String getQuery(@ModelAttribute(value = "id")QueryMaster queryMaster,BindingResult result ,Model model) {
		queryMaster = queryService.find(queryMaster.getQuery_id());
	//	System.out.println(queryMaster);
		model.addAttribute("master",queryMaster);
		return "AnswerQueryPage";
	}
	
	@RequestMapping(value = "UpdatePage" , method = RequestMethod.POST)
	public String updateQuery(@ModelAttribute(value = "master")QueryMaster query, BindingResult result, Model model) {
		QueryMaster quer= queryService.update(query);
		model.addAttribute("l",quer);
		return "Result";
	}
}
