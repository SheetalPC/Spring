package com.cg.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.QueryDAO;
import com.cg.dto.QueryMaster;

@Service
public class QueryServiceImpl implements QueryService{
	@Autowired
	QueryDAO queryDAO;

	public QueryDAO getQueryDAO() {
		return queryDAO;
	}

	public void setQueryDAO(QueryDAO queryDAO) {
		this.queryDAO = queryDAO;
	}

	@Override
	public QueryMaster find(int query_id) {
		return queryDAO.find(query_id);
	}

	@Override
	public QueryMaster update(QueryMaster query) {
		return queryDAO.update(query);
	}
}
