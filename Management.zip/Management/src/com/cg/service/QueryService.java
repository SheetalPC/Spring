package com.cg.service;
import com.cg.dto.QueryMaster;

public interface QueryService{
	public QueryMaster find(int query_id);
	public QueryMaster update(QueryMaster query);
}
