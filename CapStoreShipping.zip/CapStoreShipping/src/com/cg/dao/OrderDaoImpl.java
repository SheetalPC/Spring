package com.cg.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.cg.dto.Address;
import com.cg.dto.Order;
import com.cg.dto.User;


@Repository
@Transactional
public class OrderDaoImpl implements OrderDao{

	@PersistenceContext
	EntityManager entityManager = null;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Order getDetails(int user_id) {
		return entityManager.find(Order.class,user_id);
	}

	@Override
	public Address insertAddress(Address address) {
		entityManager.persist(address);
		return entityManager.find(Address.class, address);
	}

	@Override
	public User findId(int order_id) {
		return entityManager.find(User.class, order_id);
	}
}
