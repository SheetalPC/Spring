package com.cg.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.OrderDao;
import com.cg.dto.Address;
import com.cg.dto.Order;
import com.cg.dto.User;

@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	OrderDao orderDao = null;

	public OrderDao getCapStoreDao() {
		return orderDao;
	}

	public void setCapStoreDao(OrderDao capStoreDao) {
		this.orderDao = capStoreDao;
	}

	@Override
	public Order getDetails(int user_id) {
		return orderDao.getDetails(user_id);

	}

	@Override
	public Address insertAddress(Address address) {
		
		return orderDao.insertAddress(address);
	}

	@Override
	public User findId(int order_id) {
		return orderDao.findId(order_id);
	}


}
