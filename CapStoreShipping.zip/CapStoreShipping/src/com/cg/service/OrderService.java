package com.cg.service;

import com.cg.dto.Address;
import com.cg.dto.Order;
import com.cg.dto.User;

public interface OrderService {
	public Order getDetails(int user_id);
	//public Address insertUserDetails(Address address);
	Address insertAddress(Address address);
	public User findId(int order_id);
}
