package com.cg.dto;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="order_details")
public class Order {
	@Id
	private int order_id;
	private double total_amount;
	private String address;
	private String order_status; // shipped || in transit || out for delivery || delivered || out for
									// pickup||returned
	private Date order_date;
	private int quantity;
	private boolean status_of_transaction;
	private boolean refund_request;
	private Date refund_request_date;
	private Date eligible_return_date;

	@OneToOne
	@JoinColumn(name = "user_id")
	private User user;
	

	@OneToOne
	@JoinColumn(name = "product_id")
	private Product product;
	
	@OneToOne
	@JoinColumn(name = "coupon_id")
	private Coupon coupon;

	public Order() {
	}

	public Order(int order_id, double total_amount, String address, String order_status, Date order_date,
			int quantity, boolean status_of_transaction, boolean refund_request, Date refund_request_date,
			Date eligible_return_date, User user, Coupon coupon) {
		super();
		this.order_id = order_id;
		this.total_amount = total_amount;
		this.address = address;
		this.order_status = order_status;
		this.order_date = order_date;
		this.quantity = quantity;
		this.status_of_transaction = status_of_transaction;
		this.refund_request = refund_request;
		this.refund_request_date = refund_request_date;
		this.eligible_return_date = eligible_return_date;
		this.user = user;
		this.coupon = coupon;
	}

	public Order(double total_amount, String address, String order_status, Date order_date, int quantity,
			boolean status_of_transaction, boolean refund_request, Date refund_request_date, Date eligible_return_date,
			User user, Coupon coupon) {
		super();
		this.total_amount = total_amount;
		this.address = address;
		this.order_status = order_status;
		this.order_date = order_date;
		this.quantity = quantity;
		this.status_of_transaction = status_of_transaction;
		this.refund_request = refund_request;
		this.refund_request_date = refund_request_date;
		this.eligible_return_date = eligible_return_date;
		this.user = user;
		this.coupon = coupon;
	}

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public double getTotal_amount() {
		return total_amount;
	}

	public void setTotal_amount(double total_amount) {
		this.total_amount = total_amount;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOrder_status() {
		return order_status;
	}

	public void setOrder_status(String order_status) {
		this.order_status = order_status;
	}

	public Date getOrder_date() {
		return order_date;
	}

	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public boolean isStatus_of_transaction() {
		return status_of_transaction;
	}

	public void setStatus_of_transaction(boolean status_of_transaction) {
		this.status_of_transaction = status_of_transaction;
	}

	public boolean isRefund_request() {
		return refund_request;
	}

	public void setRefund_request(boolean refund_request) {
		this.refund_request = refund_request;
	}

	public Date getRefund_request_date() {
		return refund_request_date;
	}

	public void setRefund_request_date(Date refund_request_date) {
		this.refund_request_date = refund_request_date;
	}

	public Date getEligible_return_date() {
		return eligible_return_date;
	}

	public void setEligible_return_date(Date eligible_return_date) {
		this.eligible_return_date = eligible_return_date;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Coupon getCoupon() {
		return coupon;
	}

	public void setCoupon(Coupon coupon) {
		this.coupon = coupon;
	}


	@Override
	public String toString() {
		return "Order [order_id=" + order_id + ", total_amount=" + total_amount + ", address=" + address
				+ ", order_status=" + order_status + ", order_date=" + order_date + ", quantity=" + quantity
				+ ", status_of_transaction=" + status_of_transaction + ", refund_request=" + refund_request
				+ ", refund_request_date=" + refund_request_date + ", eligible_return_date=" + eligible_return_date
				+ ", user=" + user + ", coupon=" + coupon + "]";
	}
}
