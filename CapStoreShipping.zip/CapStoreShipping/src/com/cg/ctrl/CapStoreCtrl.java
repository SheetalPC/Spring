package com.cg.ctrl;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.dto.Address;
import com.cg.dto.Order;
import com.cg.dto.User;
import com.cg.service.OrderService;

@Controller
public class CapStoreCtrl {
	@Autowired
	OrderService orderService = null;
	
	public OrderService getCapStoreService() {
		return orderService;
	}

	public void setCapStoreService(OrderService capStoreService) {
		this.orderService = capStoreService;
	}

	@RequestMapping(value = "/Order" , method = RequestMethod.GET)
	public String getDetails(Model model) {
		model.addAttribute("details", new Address());
		return "OrderPage";
	}
	
	@RequestMapping(value = "/getId" , method = RequestMethod.POST)
	public String verificationDetails(@ModelAttribute(value="details") Address address,Model model) {
				 address = orderService.insertAddress(address);
			/*	if (user.isRefund_request()==1)
					return "RefundSuccessPage";
				else if(ord.isRefund_request()==0)
					return "Failure";
				return "Fail";*/
				 model.addAttribute("msg", address);
		return "DisplayPage";
}
	@RequestMapping(value = "/ShowRegisterPage")
	public String dispRegPage(Model model) {
		Address rd= new Address();
		model.addAttribute("reg", rd);
		return "Register";
	}
}
