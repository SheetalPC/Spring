package com.cg.controller;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Hotel;
import com.cg.service.BookingService;

@Controller
public class BookingController {
	@Autowired
	BookingService bookingService = null;

	public BookingService getBookingService() {
		return bookingService;
	}

	public void setBookingService(BookingService bookingService) {
		this.bookingService = bookingService;
	}
	
	@RequestMapping(value ="/HotelBooking" , method = RequestMethod.GET)
	public String getAllDetails(Model model) {
		ArrayList<Hotel> hotel =(ArrayList<Hotel>)bookingService.getAllDetails();
		model.addAttribute("HotelList", hotel);
		return "HotelBooking";
	}
	
	@RequestMapping(value ="/Success" , method = RequestMethod.GET)
	public String getSuccessPage(@RequestParam(value = "uid")String hotel,Model model) {
		model.addAttribute("ht", hotel);
		return "Success";
	}
	
	
	public String InsertDetailsPage(Model model) {
		model.addAttribute("insert", new Hotel());
		return "InsertDetailsPage";
	}
	
	
	public String addDetails(Model model) {
		//Hotel h = bookingService.addDetails()
		return "";
	}

}
