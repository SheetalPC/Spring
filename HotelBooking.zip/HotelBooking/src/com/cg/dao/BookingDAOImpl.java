package com.cg.dao;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.dto.Hotel;

@Repository
@Transactional
public class BookingDAOImpl implements BookingDAO{
	
	@PersistenceContext
	EntityManager entityManager = null;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public List<Hotel> getAllDetails() {
		return entityManager.createQuery("from Hotel ht" , Hotel.class).getResultList();
	}

	@Override
	public Hotel addDetails(Hotel add) {
		entityManager.persist(add);
		entityManager.flush();
		return entityManager.find(Hotel.class, add.getId());
	}

}
