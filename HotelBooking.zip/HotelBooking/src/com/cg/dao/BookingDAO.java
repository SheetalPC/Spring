package com.cg.dao;
import java.util.List;
import com.cg.dto.Hotel;

public interface BookingDAO {
	public List<Hotel> getAllDetails();
	public Hotel addDetails(Hotel add);
}
