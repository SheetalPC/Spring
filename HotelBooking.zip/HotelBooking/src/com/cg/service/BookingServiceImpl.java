package com.cg.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dao.BookingDAO;
import com.cg.dto.Hotel;

@Service
public class BookingServiceImpl implements BookingService{
	@Autowired
	BookingDAO bookingDao = null;

	public BookingDAO getBookingDao() {
		return bookingDao;
	}

	public void setBookingDao(BookingDAO bookingDao) {
		this.bookingDao = bookingDao;
	}

	@Override
	public List<Hotel> getAllDetails() {
		return bookingDao.getAllDetails();
	}

	@Override
	public Hotel addDetails(Hotel add) {
		return bookingDao.addDetails(add);
	}
	
}
