package com.cg.service;
import java.util.List;
import com.cg.dto.Hotel;

public interface BookingService {
	public List<Hotel> getAllDetails();
	public Hotel addDetails(Hotel add);
}
