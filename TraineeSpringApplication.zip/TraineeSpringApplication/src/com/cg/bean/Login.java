package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Login {
	@Id	
private String username;	
private String password;
public Login() {
}
@NotEmpty(message="username is mandatory")
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public void setPassword(String password) {
	this.password = password;
}
@NotEmpty(message="password is mandatory")
public String getPassword() {
	return password;
}

@Override
public String toString() {
	return "Login [userName=" + username + ", password=" + password + "]";
}

}
