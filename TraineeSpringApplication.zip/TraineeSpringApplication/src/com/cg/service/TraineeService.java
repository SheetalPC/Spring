package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Trainee;

public interface TraineeService {
	public  Trainee  insertUserDetails(Trainee trainee);
	public ArrayList<Trainee>getAllUserDetails();
	public Trainee deleteUsers(int tranieeId);
	public Trainee updateUsers(Trainee trainee);
	public Trainee getTraineeDetails(int traineeId);
}
