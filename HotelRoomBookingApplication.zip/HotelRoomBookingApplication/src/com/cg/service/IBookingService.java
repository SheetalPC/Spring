package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.dto.HotelBooking;

public interface IBookingService {
	public List<HotelBooking> getAllBookingDetails();
	public HotelBooking insertDetails(HotelBooking hotelBooking);
}
