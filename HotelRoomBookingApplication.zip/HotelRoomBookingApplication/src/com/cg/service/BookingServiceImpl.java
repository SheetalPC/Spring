package com.cg.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dao.IBookingDAO;
import com.cg.dto.HotelBooking;
@Service
public class BookingServiceImpl implements IBookingService{
	
	@Autowired
	IBookingDAO bookingDao = null;
	
	public IBookingDAO getBookingDao() {
		return bookingDao;
	}
	public void setBookingDao(IBookingDAO bookingDao) {
		this.bookingDao = bookingDao;
	}
	

	@Override
	public HotelBooking insertDetails(HotelBooking hotelBooking) {
		return bookingDao.insertDetails(hotelBooking);
	}
	@Override
	public List<HotelBooking>  getAllBookingDetails() {

		return bookingDao.getAllBookingDetails();
	}
	
	

}
