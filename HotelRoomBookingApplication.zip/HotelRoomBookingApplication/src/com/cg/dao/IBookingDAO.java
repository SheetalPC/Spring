package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.dto.HotelBooking;

public interface IBookingDAO {
	public List<HotelBooking> getAllBookingDetails();
	public HotelBooking insertDetails(HotelBooking hotelBooking);
}
