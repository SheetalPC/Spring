package com.cg.ctrl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Loan;
import com.cg.service.ILoanTestService;

@Controller
public class LoanTestController {

	@Autowired
	ILoanTestService loanService = null;

	public ILoanTestService getLoanService() {
		return loanService;
	}

	public void setLoanService(ILoanTestService loanService) {
		this.loanService = loanService;
	}

	/**********************Home Page***********************************************/
	@RequestMapping(value="/ShowTestEligibilityPage",method=RequestMethod.GET)
    public String dispRegPage(Model model) {
        Loan rd=new Loan();
        model.addAttribute("reg",rd);
        return "AcceptPanCard";
    }
    
	/************************Success or Failure Page*********************************/
	
    @RequestMapping(value="/testPanCard",method=RequestMethod.POST)
    public String testPancard(@ModelAttribute(value="reg")Loan loan,BindingResult result,Model model) {
        Loan cd=loanService.findDetails(loan.getPan_Card_Number());
        if(cd.getCibil_Score()>=750) {
            model.addAttribute("Obj", cd);
            return "Success";
        }
        else {
            model.addAttribute("Obj", cd);
        return "Fail";
        }
    }
}
