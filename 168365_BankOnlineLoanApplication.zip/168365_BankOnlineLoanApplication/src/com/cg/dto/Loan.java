package com.cg.dto;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Customer_Details")
public class Loan {
	@Id
	@Column(length=10)
	private String Pan_Card_Number;
	@Column(length=10)
	private String Customer_Name;
	@Column(length=20)
	private String Email_Id;
	@Column(length=10)
	private int Mobile_Number;
	@Column(length=10)
	private int Cibil_Score;
	
	public Loan() {}
	
	/****************Getters and Setters***********************/
    @NotEmpty(message="PANCARDNUMBER is mandatory to enter to test your eligibility")
    @Pattern(regexp="[A-Za-z]{5}\\d{4}[A-Za-z]{1}",message="Please follow the correct format. EX:ABCDE1234Z")
	public String getPan_Card_Number() {
		return Pan_Card_Number;
	}
	public void setPan_Card_Number(String pan_Card_Number) {
		Pan_Card_Number = pan_Card_Number;
	}
	public String getCustomer_Name() {
		return Customer_Name;
	}
	public void setCustomer_Name(String customer_Name) {
		Customer_Name = customer_Name;
	}
	public String getEmail_Id() {
		return Email_Id;
	}
	public void setEmail_Id(String email_Id) {
		Email_Id = email_Id;
	}
	public int getMobile_Number() {
		return Mobile_Number;
	}
	public void setMobile_Number(int mobile_Number) {
		Mobile_Number = mobile_Number;
	}
	public int getCibil_Score() {
		return Cibil_Score;
	}
	public void setCibil_Score(int cibil_Score) {
		Cibil_Score = cibil_Score;
	}
	@Override
	public String toString() {
		return "Loan [Pan_Card_Number=" + Pan_Card_Number + ", Customer_Name=" + Customer_Name + ", Email_Id="
				+ Email_Id + ", Mobile_Number=" + Mobile_Number + ", Cibil_Score=" + Cibil_Score + "]";
	}
	
	
}
