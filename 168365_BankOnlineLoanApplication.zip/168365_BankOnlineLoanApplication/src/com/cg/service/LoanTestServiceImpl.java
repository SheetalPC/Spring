package com.cg.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dao.ILoanTestDAO;
import com.cg.dto.Loan;

@Service
public class LoanTestServiceImpl implements ILoanTestService{

	@Autowired
	ILoanTestDAO loanDao = null;

	public ILoanTestDAO getLoanDao() {
		return loanDao;
	}

	public void setLoanDao(ILoanTestDAO loanDao) {
		this.loanDao = loanDao;
	}
	
	@Override
	public Loan findDetails(String Pan_Card_Number) {
		return loanDao.findDetails(Pan_Card_Number);
	}

	@Override
	public boolean PanCardExist(String Pan_Card_Number) {
		return loanDao.PanCardExist(Pan_Card_Number);
	}
	
}
