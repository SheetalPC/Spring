package com.cg.service;

import com.cg.dto.Loan;

public interface ILoanTestService {
	public Loan findDetails(String Pan_Card_Number);
	public boolean PanCardExist(String Pan_Card_Number);
}
