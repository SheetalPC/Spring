package com.cg.dao;

import com.cg.dto.Loan;

public interface ILoanTestDAO {
	public Loan findDetails(String Pan_Card_Number);
	public boolean PanCardExist(String Pan_Card_Number);
}
