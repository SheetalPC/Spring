package com.cg.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.dto.Loan;

@Repository
@Transactional
public class LoanTestDAOImpl implements ILoanTestDAO{

	@PersistenceContext
	EntityManager entityManager = null;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Loan findDetails(String Pan_Card_Number) {
		return entityManager.find(Loan.class, Pan_Card_Number);
	}

	@Override
	public boolean PanCardExist(String Pan_Card_Number) {
		Loan pan=entityManager.find(Loan.class, Pan_Card_Number);
        if(pan!=null) {
            return true;
        }else {
            return false;
        }   
}
}
