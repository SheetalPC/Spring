package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpringReadpropDemo {
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("cgbeans.xml");
		User myCredentials = (User)ctx.getBean("user1");
		System.out.println(myCredentials);
	}
}
