package com.cg.staticdb;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Country;

public class CountryDb {
	private static ArrayList<Country> countryList = new ArrayList<Country>();
	static
	{
		countryList.add(new Country("1001","India","3234567"));
		countryList.add(new Country("1002","Pakistan","65425"));
		countryList.add(new Country("1003","SriLanka","78742"));
		countryList.add(new Country("1004","China","78615"));
		countryList.add(new Country("1005","USA","956147"));
	}
	
	public static ArrayList<Country> getCountryList(){
		return countryList;
	}
	
	public static void setCountryList(List<Country> countryList) {
		CountryDb.countryList = (ArrayList<Country>) CountryDb.countryList;
	}
}
