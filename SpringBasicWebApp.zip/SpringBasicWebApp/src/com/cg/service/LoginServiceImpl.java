package com.cg.service;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ILoginDao;
import com.cg.dto.Login;
import com.cg.dto.RegisterDto;
@Service("loginSer") // this is a service coponent
public class LoginServiceImpl implements ILoginService{
	@Autowired
	ILoginDao logDao = null;
	
	@Override
	public boolean isUserExist(String usn) {
		return logDao.isUserExist(usn);
	}

	public ILoginDao getLoginDao() {
		return logDao;
	}
	
	public void setLoginDao(ILoginDao loginDao) {
		this.logDao = loginDao;
	}

	@Override
	public Login validateUser(Login login) {
		Login dbUser = logDao.validateUser(login);
		if((login.getUsername().equalsIgnoreCase(dbUser.getUsername())) &&
				login.getPassword().equalsIgnoreCase(dbUser.getPassword()))
			return login;
			return null;
	}

	@Override
	public RegisterDto insertUserDetails(RegisterDto userDetails) {
		return logDao.insertUserDetails(userDetails);
	}

	@Override
	public ArrayList<RegisterDto> getAllUserDeatils() {
		return logDao.getAllUserDeatils();
	}

	@Override
	public RegisterDto deleteUsrs(String usn) {
		return logDao.deleteUsrs(usn);
	}
}
